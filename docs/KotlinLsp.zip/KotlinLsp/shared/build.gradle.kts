plugins {
    // kotlin("jvm")
    id("com.android.library")
    id("kotlin-android")
    alias(ktlsp.plugins.com.google.protobuf)
}


android {
namespace = "org.javacs.kt.shared"
    compileSdk = 34

    defaultConfig {
        minSdk = 21
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        
    }

    kotlinOptions {
        jvmTarget = "11" 
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

}

configurations.all {
    resolutionStrategy {
        force(ktlsp.org.jetbrains.kotlin.stdlib)
        force(ktlsp.hamcrest.all)
        force(ktlsp.junit.junit)
        force(ktlsp.org.eclipse.lsp4j.lsp4j)
        force(ktlsp.org.eclipse.lsp4j.jsonrpc)
        force(ktlsp.org.jetbrains.kotlin.compiler)
        force(ktlsp.org.jetbrains.kotlin.kotlin.scripting.jvm.host)
        force(ktlsp.org.jetbrains.kotlin.ktscompiler)
        force(ktlsp.org.jetbrains.kotlin.kts.jvm.host.unshaded)
        force(ktlsp.org.jetbrains.kotlin.sam.with.receiver.compiler.plugin)
        force(ktlsp.org.jetbrains.kotlin.reflect)
        // force(ktlsp.org.jetbrains.kotlin.jvm)
        // force(ktlsp.org.jetbrains.fernflower)
        force(ktlsp.org.jetbrains.exposed.core)
        force(ktlsp.org.jetbrains.exposed.dao)
        force(ktlsp.org.jetbrains.exposed.jdbc)
        
        force(ktlsp.com.google.guava.guava)
    }

          exclude(group = "org.hamcrest", module = "hamcrest-core")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-reflect")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host-unshaded")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-sam-with-receiver-compiler-plugin")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-script-runtime")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-common")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler(")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host-unshaded")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlinx-coroutines-core-jvm")
        
}


dependencies {
    // dependencies are constrained to versions defined
    // in /platform/build.gradle.kts
    implementation(platform(project(":editor:KotlinLsp:platform")))

    implementation(kotlin("stdlib"))
    implementation(ktlsp.com.google.code.gson)
    implementation(ktlsp.org.jetbrains.exposed.core)
    implementation(ktlsp.org.jetbrains.exposed.dao)
    implementation(ktlsp.com.google.protobuf.java)
    implementation(ktlsp.com.google.protobuf.java.util)
    testImplementation(ktlsp.hamcrest.all)
    testImplementation(ktlsp.junit.junit)
}

protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:3.25.3"
    }
}


kotlin {
    jvmToolchain(11)
}

