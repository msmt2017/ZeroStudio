plugins {
    id("com.android.library")
    id("kotlin-android")
    // alias(ktlsp.plugins.kotlin.jvm)
    alias(ktlsp.plugins.com.github.jk1.tcdeps)
    alias(ktlsp.plugins.com.jaredsburrows.license)
      
}

android {
    namespace = "org.javacs.kt"
    compileSdk = 34

    defaultConfig {
        minSdk = 21
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    kotlinOptions {
        jvmTarget = "11" 
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

}
configurations.all {
    resolutionStrategy {
        force(ktlsp.org.jetbrains.kotlin.stdlib)
        force(ktlsp.hamcrest.all)
        force(ktlsp.junit.junit)
        force(ktlsp.org.eclipse.lsp4j.lsp4j)
        force(ktlsp.org.eclipse.lsp4j.jsonrpc)
        force(ktlsp.org.jetbrains.kotlin.compiler)
        force(ktlsp.org.jetbrains.kotlin.kotlin.scripting.jvm.host)
        force(ktlsp.org.jetbrains.kotlin.ktscompiler)
        force(ktlsp.org.jetbrains.kotlin.kts.jvm.host.unshaded)
        force(ktlsp.org.jetbrains.kotlin.sam.with.receiver.compiler.plugin)
        force(ktlsp.org.jetbrains.kotlin.reflect)
        // force(ktlsp.org.jetbrains.kotlin.jvm)
        // force(ktlsp.org.jetbrains.fernflower)
        force(ktlsp.org.jetbrains.exposed.core)
        force(ktlsp.org.jetbrains.exposed.dao)
        force(ktlsp.org.jetbrains.exposed.jdbc)
        
        force(ktlsp.com.google.guava.guava)
        
        // force(project(":composite-builds:build-deps:google-java-format"))
        

    }

          exclude(group = "org.hamcrest", module = "hamcrest-core")
      
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-reflect")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host-unshaded")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-sam-with-receiver-compiler-plugin")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-script-runtime")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-common")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler(")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-jvm-host-unshaded")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlinx-coroutines-core-jvm")
        
}

kotlin {
    jvmToolchain(11)
}

dependencies {
        api(ktlsp.org.jetbrains.kotlin.stdlib){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        api(ktlsp.hamcrest.all){
            exclude(group = "org.hamcrest", module = "hamcrest-core")
            }
        api(ktlsp.junit.junit)
        api(ktlsp.org.eclipse.lsp4j.lsp4j)
        api(ktlsp.org.eclipse.lsp4j.jsonrpc)
        implementation(files("libs/kotlin-compiler-2.0.0.jar"))
        // api(ktlsp.org.jetbrains.kotlin.compiler){ 
        // exclude(group = "com.google.guava", module = "guava")
        // exclude(group = "org.jline", module = "jline")
        // exclude(group = "net.java.dev.jna", module = "jna-platform")
        // exclude(group = "net.java.dev.jna", module = "jna")
        // }
        api(ktlsp.org.jetbrains.kotlin.ktscompiler){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        api(ktlsp.org.jetbrains.kotlin.kts.jvm.host.unshaded){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        api(ktlsp.org.jetbrains.kotlin.sam.with.receiver.compiler.plugin){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        api(ktlsp.org.jetbrains.kotlin.reflect){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        // api(ktlsp.org.jetbrains.kotlin.jvm)
        api(ktlsp.com.jetbrains.intellij.java.decompiler)
        api(ktlsp.org.jetbrains.exposed.core)
        api(ktlsp.org.jetbrains.exposed.dao)
        api(ktlsp.org.jetbrains.exposed.jdbc)
        api(ktlsp.com.h2database.h2)
        api(ktlsp.com.google.guava.guava)
        api(ktlsp.com.github.fwcd.ktfmt){
        exclude(group = "com.google.guava", module = "guava")
        }
        api(ktlsp.com.beust.jcommander)
        api(ktlsp.org.openjdk.jmh.core)
        api(ktlsp.org.jetbrains.kotlin.kotlin.scripting.jvm.host){
        exclude(group = "com.google.guava", module = "guava")
        exclude(group = "org.jline", module = "jline")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        }
        api(ktlsp.org.openjdk.jmh.generator.annprocess)
        api(ktlsp.org.xerial.sqlite.jdbc)
        api(ktlsp.com.google.code.gson)
        
            // dependencies are constrained to versions defined
    // in /platform/build.gradle.kts
    // implementation(platform(project(":editor:KotlinLsp:platform")))
    // annotationProcessor(platform(project(":editor:KotlinLsp:platform")))
    implementation("zerostudio:kotlin-psitype:2.1.0")
    // implementation(project(":editor:KotlinLsp:shared"))
    implementation(files("libs/shared-1.6.5-bazel.jar"))
    implementation(ktlsp.org.eclipse.lsp4j.lsp4j)
    implementation(ktlsp.org.eclipse.lsp4j.jsonrpc)

    // implementation(kotlin("compiler"))
    // implementation(kotlin("scripting-compiler"))
    // implementation(kotlin("scripting-jvm-host-unshaded"))
    // implementation(kotlin("sam-with-receiver-compiler-plugin"))
    // implementation(kotlin("reflect"))
    implementation(ktlsp.com.jetbrains.intellij.java.decompiler)
    implementation(ktlsp.org.jetbrains.exposed.core)
    implementation(ktlsp.org.jetbrains.exposed.dao)
    implementation(ktlsp.org.jetbrains.exposed.jdbc)
    implementation(ktlsp.com.h2database.h2)
    // implementation(ktlsp.com.github.fwcd.ktfmt)
    implementation(ktlsp.com.beust.jcommander)
    implementation(ktlsp.org.xerial.sqlite.jdbc)
    implementation(ktlsp.com.google.protobuf.java)

    testImplementation(ktlsp.hamcrest.all)
    testImplementation(ktlsp.junit.junit)
    testImplementation(ktlsp.org.openjdk.jmh.core)

    // See
    // https://github.com/JetBrains/kotlin/blob/65b0a5f90328f4b9addd3a10c6f24f3037482276/libraries/examples/scripting/jvm-embeddable-host/build.gradle.kts#L8
    // compileOnly(kotlin("scripting-jvm-host"))
    // testCompileOnly(kotlin("scripting-jvm-host"))

    annotationProcessor(ktlsp.org.openjdk.jmh.generator.annprocess)
    
}

// dependencies {

     // implementation(files("libs/kotlin-compiler-2.0.0.jar")) //使用定制版，避免使用在线maven原版产生重复class冲突
     // implementation("zerostudio:kotlin-psitype:2.1.0")
     // implementation(fileTree(mapOf("dir" to "lib", "include" to listOf("*.jar", "*.aar"))))
     
    // // implementation(platform(project(":editor:KotlinLsp:platform")))
    // // annotationProcessor(platform(project(":editor:KotlinLsp:platform")))
    // implementation(project(":editor:KotlinLsp:shared"))
    
    // implementation(projects.core.common)
    // // implementation(projects.termux.application)
    // // implementation(projects.termux.view)
    // implementation(projects.termux.emulator)
    // implementation(projects.termux.shared)
    // implementation(projects.java.lsp)
  
  // implementation("androidx.core:core-ktx:1.12.0")
    // implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    
    // // LSP4J 库，用于语言服务器协议，运行时需要
    // implementation(ktlsp.org.eclipse.lsp4j.lsp4j)
    // implementation(ktlsp.org.eclipse.lsp4j.jsonrpc)
    
        // api(ktlsp.org.jetbrains.kotlin.stdlib)
        // api(ktlsp.hamcrest.all){
            // exclude(group = "org.hamcrest", module = "hamcrest-core")
            // }

        // api(ktlsp.junit.junit)
        // api(ktlsp.org.eclipse.lsp4j.lsp4j)
        // api(ktlsp.org.eclipse.lsp4j.jsonrpc)
        // // api(ktlsp.org.jetbrains.kotlin.compiler){ //不建议使用在线版本，因为重复class的冲突问题无法解决
        // // exclude(group = "com.google.guava", module = "guava")
        // // exclude(group = "org.jline", module = "jline")
        // // exclude(group = "net.java.dev.jna", module = "jna-platform")
        // // exclude(group = "net.java.dev.jna", module = "jna")
        // // }
        // api(ktlsp.org.jetbrains.kotlin.kotlin.scripting.jvm.host){
        // exclude(group = "com.google.guava", module = "guava")
        // exclude(group = "org.jline", module = "jline")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        // }
        // api(ktlsp.org.jetbrains.kotlin.ktscompiler){
        // exclude(group = "com.google.guava", module = "guava")
        // exclude(group = "org.jline", module = "jline")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-embeddable")
        // exclude(group = "org.jetbrains.kotlin", module = "kotlin-scripting-compiler-impl-embeddable")
        // }
        // // api(ktlsp.org.jetbrains.kotlin.kts.jvm.host.unshaded){ //与kotlin-scripting-jvm-host的class完全重复
        // // exclude(group = "com.google.guava", module = "guava")
        // // exclude(group = "org.jline", module = "jline")
        // // exclude(group = "org.jetbrains.kotlin", module = "kotlin-compiler")
        // // }
        // api(ktlsp.org.jetbrains.kotlin.sam.with.receiver.compiler.plugin)
        // api(ktlsp.org.jetbrains.kotlin.reflect)
        // // api(ktlsp.org.jetbrains.kotlin.jvm)
        // api(ktlsp.org.jetbrains.fernflower)
        // api(ktlsp.org.jetbrains.exposed.core)
        // api(ktlsp.org.jetbrains.exposed.dao)
        // api(ktlsp.org.jetbrains.exposed.jdbc)
        
        // api(ktlsp.com.h2database.h2)
        // api(ktlsp.com.google.guava.guava)
        // api(ktlsp.com.github.fwcd.ktfmt){
        // exclude(group = "com.google.guava", module = "guava")
        // }
        // api(ktlsp.com.beust.jcommander)
        // api(ktlsp.org.openjdk.jmh.core)
        // api(ktlsp.org.openjdk.jmh.generator.annprocess)
        // api(ktlsp.org.xerial.sqlite.jdbc)

    // // 数据库和持久化
    // implementation(ktlsp.org.jetbrains.exposed.core)
    // implementation(ktlsp.org.jetbrains.exposed.dao)
    // implementation(ktlsp.org.jetbrains.exposed.jdbc)
    // implementation(ktlsp.com.h2database.h2)
    // implementation(ktlsp.org.xerial.sqlite.jdbc)
    
    // //使用本地环境配置的谷歌格式化
    // implementation(ktlsp.composite.googleJavaFormat)
    
    // // --- 测试依赖 ---
    // testImplementation(ktlsp.hamcrest.all)
    // testImplementation(ktlsp.junit.junit)
    // testImplementation(ktlsp.org.openjdk.jmh.core)
    // testImplementation(projects.testing.commonTest)
    // testImplementation(projects.testing.lspTest)
    // androidTestImplementation(projects.testing.androidTest)
    // androidTestImplementation(projects.utilities.shared)
    
    // // 脚本宿主，同样只在编译时需要
    // testCompileOnly(kotlin("scripting-jvm-host"))
    // compileOnly(kotlin("scripting-jvm-host"))
    
    // annotationProcessor(ktlsp.org.openjdk.jmh.generator.annprocess)
    
    // implementation(projects.core.lspApi)
    // implementation(projects.core.lspModels)
    // implementation(projects.core.projects)
// }
