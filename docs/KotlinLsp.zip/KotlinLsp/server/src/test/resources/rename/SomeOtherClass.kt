package rename

class SomeOtherClass {
}
