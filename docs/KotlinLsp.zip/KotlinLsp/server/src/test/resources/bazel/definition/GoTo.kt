object GoTo {
    fun methodInDifferentFile() {

    }
}