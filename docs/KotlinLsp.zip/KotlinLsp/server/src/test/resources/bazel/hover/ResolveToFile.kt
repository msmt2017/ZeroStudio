object ResolveToFile {
    fun target() {

    }
}